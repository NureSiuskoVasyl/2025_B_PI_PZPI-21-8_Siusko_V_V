import { get, reject } from "lodash";
import moment from "moment/moment";
import { createSelector } from "reselect";

// === СТАРІ СЕЛЕКТОРИ (зберігаємо для сумісності) ===
const allData = (state) => get(state, "medical.allMedical.data", []);
const deleteData = (state) => get(state, "medical.deleteMedical.data", []);
const account = (state) => get(state, "provider.account");
const events = (state) => get(state, "medical.events", []);

// === НОВІ СЕЛЕКТОРИ ДЛЯ РОЛЕЙ ===
const userRole = (state) => get(state, "medical.userRole.role", "NONE");
const isUserRegistered = (state) => get(state, "medical.userRole.isRegistered", false);
const myRecords = (state) => get(state, "medical.myRecords.data", []);
const patientRecords = (state) => get(state, "medical.patientRecords.data", []);
const allRecords = (state) => get(state, "medical.allRecords.data", []);

// === СЕЛЕКТОРИ ДЛЯ РОЛЕЙ ===
export const userRoleSelector = createSelector(
  [userRole, isUserRegistered],
  (role, registered) => ({
    role,
    isRegistered: registered,
    isAdmin: role === "ADMIN",
    isDoctor: role === "DOCTOR",
    isPatient: role === "PATIENT",
    isNone: role === "NONE",
  })
);

// === СЕЛЕКТОРИ ЗАПИСІВ ДЛЯ РІЗНИХ РОЛЕЙ ===

// Для пацієнтів - тільки свої записи
export const myRecordsSelector = createSelector(
  [myRecords],
  (records) => {
    if (!Array.isArray(records)) return [];
    return records.map((record) => decorateRecord(record));
  }
);

// Для лікарів - записи конкретного пацієнта
export const patientRecordsSelector = createSelector(
  [patientRecords],
  (records) => {
    if (!Array.isArray(records)) return [];
    return records.map((record) => decorateRecord(record));
  }
);

// Для лікарів/адміна - всі записи
export const allRecordsSelector = createSelector(
  [allRecords],
  (records) => {
    if (!Array.isArray(records)) return [];
    return records.map((record) => decorateRecord(record));
  }
);

// === СТАРИЙ СЕЛЕКТОР (модифікований для нової структури) ===
const openData = (state) => {
  const all = allData(state);
  const delet = deleteData(state);
  
  if (!Array.isArray(all) || !Array.isArray(delet)) return [];
  
  const openData = reject(all, (data) => {
    const dataDeleted = delet.some(
      (o) => o.recordId && data.recordId && o.recordId.toString() === data.recordId.toString()
    );
    return dataDeleted;
  });
  return openData;
};

export const dataBookSelector = createSelector([openData], (data) => {
  if (!Array.isArray(data)) return [];
  return decorateOpenData(data);
});

// === УНІВЕРСАЛЬНИЙ СЕЛЕКТОР НА ОСНОВІ РОЛІ ===
export const recordsForCurrentUserSelector = createSelector(
  [userRole, myRecords, allRecords],
  (role, myRecs, allRecs) => {
    let records = [];
    
    switch (role) {
      case "PATIENT":
        records = Array.isArray(myRecs) ? myRecs : [];
        break;
      case "DOCTOR":
      case "ADMIN":
        records = Array.isArray(allRecs) ? allRecs : [];
        break;
      default:
        records = [];
    }
    
    return records.map((record) => decorateRecord(record));
  }
);

// === ДОПОМІЖНІ ФУНКЦІЇ ===
const decorateOpenData = (datas) => {
  if (!Array.isArray(datas)) return [];
  return datas.map((data) => {
    return decorateOrder(data);
  });
};

// Функція для безпечної конвертації BigNumber в рядок
const safeToString = (value) => {
  if (!value) return "0";
  if (typeof value === 'string') return value;
  if (typeof value === 'number') return value.toString();
  if (value._isBigNumber || value._hex) return value.toString();
  return String(value);
};

// Функція для безпечної конвертації BigNumber в число
const safeToNumber = (value) => {
  if (!value) return 0;
  if (typeof value === 'number') return value;
  if (typeof value === 'string') return parseInt(value) || 0;
  if (value._isBigNumber || value._hex) return parseInt(value.toString()) || 0;
  return 0;
};

// Старий декоратор для сумісності
export const decorateOrder = (data) => {
  if (!data || typeof data !== 'object') return {};
  
  const recordId = safeToString(data.recordId);
  const age = safeToNumber(data.age);
  const timestamp = safeToNumber(data.timestamp);
  
  return {
    ...data,
    recordId: recordId,
    recordIdNew: parseFloat(recordId),
    age: age,
    ageNew: age,
    timestamp: timestamp,
    formattedTimestamp: timestamp 
      ? moment.unix(timestamp).format("h:mm:ssa d MMM yyyy")
      : "Unknown",
  };
};

// Новий декоратор для записів з ролями
const decorateRecord = (record) => {
  if (!record || typeof record !== 'object') return {};
  
  const recordId = safeToString(record.recordId);
  const age = safeToNumber(record.age);
  const timestamp = safeToNumber(record.timestamp);
  
  return {
    ...record,
    recordId: recordId,
    recordIdNew: parseFloat(recordId),
    age: age,
    ageNew: age,
    timestamp: timestamp,
    formattedTimestamp: timestamp 
      ? moment.unix(timestamp).format("h:mm:ssa d MMM yyyy")
      : "Unknown",
    shortPatient: record.patient 
      ? `${record.patient.slice(0, 6)}...${record.patient.slice(-4)}`
      : "Unknown",
    shortDoctor: record.doctor 
      ? `${record.doctor.slice(0, 6)}...${record.doctor.slice(-4)}`
      : "Unknown",
    // Конвертуємо всі можливі BigNumber поля в рядки
    name: record.name ? String(record.name) : "Unknown",
    gender: record.gender ? String(record.gender) : "Unknown",
    bloodType: record.bloodType ? String(record.bloodType) : "Unknown",
    allergies: record.allergies ? String(record.allergies) : "Unknown",
    diagnosis: record.diagnosis ? String(record.diagnosis) : "Unknown",
    treatment: record.treatment ? String(record.treatment) : "Unknown",
    patient: record.patient ? String(record.patient) : "Unknown",
    doctor: record.doctor ? String(record.doctor) : "Unknown",
  };
};

// === ІНШІ СЕЛЕКТОРИ ===
export const myEventsSelector = createSelector(
  [account, events],
  (account, events) => {
    if (!Array.isArray(events)) return [];
    return events;
  }
);

// Селектор для перевірки чи може користувач виконати дію
export const canPerformActionSelector = createSelector(
  [userRole, isUserRegistered],
  (role, registered) => ({
    canAddRecord: role === "DOCTOR",
    canDeleteRecord: role === "DOCTOR" || role === "ADMIN",
    canViewAllRecords: role === "DOCTOR" || role === "ADMIN",
    canAssignDoctors: role === "ADMIN",
    canRegisterAsPatient: !registered && role === "NONE",
    canViewOwnRecords: role === "PATIENT",
  })
);