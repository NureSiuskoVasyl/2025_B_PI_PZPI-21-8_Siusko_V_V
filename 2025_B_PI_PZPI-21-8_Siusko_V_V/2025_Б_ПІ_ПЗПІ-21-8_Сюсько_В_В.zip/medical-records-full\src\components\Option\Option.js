import React from "react";
import "./option.css";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { userRoleSelector } from "../../store/selectors";

const Option = () => {
  const { t } = useTranslation();
  const userRole = useSelector(userRoleSelector);
  
  return (
    <div className="Option">
      <Link to="/" className="opt__form">
        {t('navigation.form')}
      </Link>
      <Link to="/data" className="opt__data">
        {t('navigation.data')}
      </Link>
      
      {/* Показуємо Pending Records для пацієнтів і лікарів */}
      {(userRole.isPatient || userRole.isDoctor) && (
        <Link to="/pending" className="opt__pending">
          {t('navigation.pendingRecords')}
        </Link>
      )}
      
      {/* Показуємо Admin Panel тільки для адміністраторів */}
      {userRole.isAdmin && (
        <Link to="/admin" className="opt__admin">
          {t('navigation.adminPanel')}
        </Link>
      )}
      
      {/* Показуємо Patient Registration тільки для незареєстрованих */}
      {userRole.isNone && !userRole.isRegistered && (
        <Link to="/register" className="opt__register">
          {t('navigation.register')}
        </Link>
      )}
    </div>
  );
};

export default Option;