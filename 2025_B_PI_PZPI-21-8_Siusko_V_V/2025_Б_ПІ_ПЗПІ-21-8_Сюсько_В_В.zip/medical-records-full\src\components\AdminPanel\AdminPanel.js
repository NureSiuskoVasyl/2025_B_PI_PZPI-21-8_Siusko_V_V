import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { assignDoctor, loadAllUsers, loadUserStatistics, removeDoctorRole, searchUser } from "../../store/interactions";
import { useTranslation } from "react-i18next";
import "./adminPanel.css";

const AdminPanel = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const provider = useSelector((state) => state.provider.connection);
  const medical = useSelector((state) => state.medical.contract);
  const account = useSelector((state) => state.provider.account);
  const allUsers = useSelector((state) => state.medical.allUsers);
  const userStatistics = useSelector((state) => state.medical.userStatistics);
  
  const [doctorAddress, setDoctorAddress] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [searchAddress, setSearchAddress] = useState("");
  const [searchResult, setSearchResult] = useState(null);
  const [activeModal, setActiveModal] = useState(null); // 'users', 'doctors', 'patients'
  const [filteredUsers, setFilteredUsers] = useState([]);

  // Завантаження користувачів при монтуванні компонента
  useEffect(() => {
    if (medical && provider && account) {
      loadAllUsers(medical, provider, dispatch);
      loadUserStatistics(medical, provider, dispatch);
    }
  }, [medical, provider, account, dispatch]);

  // Фільтрація користувачів при зміні activeModal або даних
  useEffect(() => {
    if (allUsers.data) {
      switch (activeModal) {
        case 'users':
          setFilteredUsers(allUsers.data);
          break;
        case 'doctors':
          setFilteredUsers(allUsers.data.filter(user => user.role === 'DOCTOR'));
          break;
        case 'patients':
          setFilteredUsers(allUsers.data.filter(user => user.role === 'PATIENT'));
          break;
        default:
          setFilteredUsers([]);
      }
    }
  }, [activeModal, allUsers.data]);

  const assignDoctorHandler = async (e) => {
    e.preventDefault();
    
    if (!doctorAddress) {
      alert(t('adminPanel.alerts.enterDoctorAddress'));
      return;
    }

    if (!doctorAddress.match(/^0x[a-fA-F0-9]{40}$/)) {
      alert(t('adminPanel.alerts.enterValidAddress'));
      return;
    }

    setIsLoading(true);
    try {
      await assignDoctor(medical, doctorAddress, provider, dispatch);
      alert(t('adminPanel.alerts.doctorAssignedSuccess'));
      setDoctorAddress("");
      // Перезавантажуємо користувачів
      await loadAllUsers(medical, provider, dispatch);
      await loadUserStatistics(medical, provider, dispatch);
    } catch (error) {
      console.error("Error assigning doctor:", error);
      alert(t('adminPanel.alerts.assignDoctorFailed'));
    }
    setIsLoading(false);
  };

  const removeDoctorHandler = async (doctorAddress) => {
    if (!window.confirm(t('adminPanel.alerts.confirmRemoveDoctor', { address: doctorAddress }))) {
      return;
    }

    try {
      await removeDoctorRole(medical, doctorAddress, provider, dispatch);
      alert(t('adminPanel.alerts.doctorRemovedSuccess'));
      // Перезавантажуємо користувачів
      await loadAllUsers(medical, provider, dispatch);
      await loadUserStatistics(medical, provider, dispatch);
    } catch (error) {
      console.error("Error removing doctor:", error);
      alert(t('adminPanel.alerts.removeDoctorFailed', { message: error.message }));
    }
  };

  const searchUserHandler = async () => {
    if (!searchAddress) {
      alert(t('adminPanel.alerts.enterSearchAddress'));
      return;
    }

    try {
      const result = await searchUser(medical, searchAddress, provider);
      setSearchResult(result);
    } catch (error) {
      console.error("Error searching user:", error);
      alert(t('adminPanel.alerts.searchFailed', { message: error.message }));
      setSearchResult(null);
    }
  };

  const refreshData = async () => {
    if (medical && provider) {
      await loadAllUsers(medical, provider, dispatch);
      await loadUserStatistics(medical, provider, dispatch);
    }
  };

  const openModal = (modalType) => {
    setActiveModal(modalType);
  };

  const closeModal = () => {
    setActiveModal(null);
    setFilteredUsers([]);
  };

  const quickAssignButtons = [
    {
      name: t('adminPanel.quickAssignAccounts.account2'),
      address: "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC",
    },
    {
      name: t('adminPanel.quickAssignAccounts.account3'), 
      address: "0x90F79bf6EB2c4f870365E785982E1f101E93b906",
    },
    {
      name: t('adminPanel.quickAssignAccounts.account4'),
      address: "0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65",
    }
  ];

  const formatAddress = (address) => `${address.slice(0, 6)}...${address.slice(-4)}`;

  return (
    <div className="admin-panel">
      <div className="admin-header">
        <h1>{t('adminPanel.title')}</h1>
        <p>{t('adminPanel.currentAdmin')} {account?.slice(0, 6)}...{account?.slice(-4)}</p>
        <button onClick={refreshData} className="refresh-btn">{t('adminPanel.refreshData')}</button>
      </div>

      {/* Статистика користувачів */}
      {userStatistics.data && (
        <div className="statistics-section">
          <h2>{t('adminPanel.userStatistics')}</h2>
          <div className="stats-grid">
            <div className="stat-card total">
              <h3>{userStatistics.data.total}</h3>
              <p>{t('adminPanel.totalUsers')}</p>
            </div>
            <div className="stat-card admins">
              <h3>{userStatistics.data.admins}</h3>
              <p>{t('adminPanel.admins')}</p>
            </div>
            <div className="stat-card doctors">
              <h3>{userStatistics.data.doctors}</h3>
              <p>{t('adminPanel.doctors')}</p>
            </div>
            <div className="stat-card patients">
              <h3>{userStatistics.data.patients}</h3>
              <p>{t('adminPanel.patients')}</p>
            </div>
            <div className="stat-card inactive">
              <h3>{userStatistics.data.inactive}</h3>
              <p>{t('adminPanel.inactive')}</p>
            </div>
          </div>
        </div>
      )}

      {/* Пошук користувача */}
      <div className="search-section">
        <h2>{t('adminPanel.searchUser')}</h2>
        <div className="search-form">
          <input
            type="text"
            value={searchAddress}
            onChange={(e) => setSearchAddress(e.target.value)}
            placeholder={t('adminPanel.searchPlaceholder')}
            className="search-input"
          />
          <button onClick={searchUserHandler} className="search-btn">
            {t('adminPanel.search')}
          </button>
        </div>
        
        {searchResult && (
          <div className="search-result">
            <h3>{t('adminPanel.searchResult')}</h3>
            <div className="user-info">
              <p><strong>{t('adminPanel.address')}</strong> {searchResult.address}</p>
              <p><strong>{t('adminPanel.role')}</strong> <span className={`role-badge role-${searchResult.role.toLowerCase()}`}>{searchResult.role}</span></p>
              <p><strong>{t('adminPanel.registered')}</strong> {searchResult.isRegistered ? "✅ Так" : "❌ Ні"}</p>
              <p><strong>{t('adminPanel.balance')}</strong> {searchResult.balance} ETH</p>
              {searchResult.totalRecords && (
                <p><strong>{t('adminPanel.totalRecords')}</strong> {searchResult.totalRecords}</p>
              )}
              {searchResult.pendingRecords && (
                <p><strong>{t('adminPanel.pendingRecords')}</strong> {searchResult.pendingRecords}</p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Призначення лікаря */}
      <div className="assign-doctor-section">
        <h2>{t('adminPanel.assignDoctor')}</h2>
        <form onSubmit={assignDoctorHandler}>
          <div className="form-group">
            <label htmlFor="doctorAddress">{t('adminPanel.doctorAddress')}</label>
            <input
              type="text"
              id="doctorAddress"
              value={doctorAddress}
              onChange={(e) => setDoctorAddress(e.target.value)}
              placeholder="0x..."
              required
              className="address-input"
            />
          </div>
          
          <button 
            type="submit" 
            disabled={isLoading}
            className="assign-btn"
          >
            {isLoading ? t('adminPanel.assigning') : t('adminPanel.assignBtn')}
          </button>
        </form>

        <div className="quick-assign">
          <h3>{t('adminPanel.quickAssign')}</h3>
          <div className="quick-buttons">
            {quickAssignButtons.map((account, index) => (
              <button
                key={index}
                onClick={() => setDoctorAddress(account.address)}
                className="quick-btn"
              >
                {account.name}
                <br />
                <small>{account.address.slice(0, 8)}...</small>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Дії адміністратора */}
      <div className="admin-actions">
        <h2>{t('adminPanel.adminActions')}</h2>
        <div className="action-buttons">
          <button 
            className="action-btn view-all"
            onClick={() => openModal('users')}
            disabled={allUsers.loading}
          >
            {allUsers.loading ? "Завантаження..." : t('adminPanel.viewAllUsers')}
          </button>
          <button 
            className="action-btn view-doctors"
            onClick={() => openModal('doctors')}
            disabled={allUsers.loading}
          >
            {t('adminPanel.viewAllDoctors')}
          </button>
          <button 
            className="action-btn view-patients"
            onClick={() => openModal('patients')}
            disabled={allUsers.loading}
          >
            {t('adminPanel.viewAllPatients')}
          </button>
        </div>
      </div>

      {/* Модальне вікно для перегляду користувачів */}
      {activeModal && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>
                {activeModal === 'users' && t('adminPanel.allUsers')}
                {activeModal === 'doctors' && t('adminPanel.allDoctors')}
                {activeModal === 'patients' && t('adminPanel.allPatients')}
              </h2>
              <button onClick={closeModal} className="close-btn">✕</button>
            </div>
            
            <div className="modal-body">
              {filteredUsers.length === 0 ? (
                <p>{t('adminPanel.noUsersFound')}</p>
              ) : (
                <div className="users-table">
                  <table>
                    <thead>
                      <tr>
                        <th>{t('adminPanel.address')}</th>
                        <th>{t('adminPanel.role')}</th>
                        <th>{t('adminPanel.status')}</th>
                        <th>{t('adminPanel.balance')}</th>
                        {activeModal === 'doctors' && <th>{t('adminPanel.actions')}</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.map((user, index) => (
                        <tr key={index}>
                          <td>
                            <code>{formatAddress(user.address)}</code>
                            <br />
                            <small style={{color: '#666'}}>{user.address}</small>
                          </td>
                          <td>
                            <span className={`role-badge role-${user.role.toLowerCase()}`}>
                              {user.role}
                            </span>
                          </td>
                          <td>
                            {user.isRegistered ? (
                              <span className="status-active">{t('adminPanel.statusActive')}</span>
                            ) : (
                              <span className="status-inactive">{t('adminPanel.statusInactive')}</span>
                            )}
                          </td>
                          <td>{user.balance} ETH</td>
                          {activeModal === 'doctors' && (
                            <td>
                              <button
                                onClick={() => removeDoctorHandler(user.address)}
                                className="remove-btn"
                                disabled={user.address === account}
                              >
                                {t('adminPanel.removeDoctor')}
                              </button>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Системна інформація */}
      <div className="system-info">
        <h2>{t('adminPanel.systemInfo')}</h2>
        <div className="info-grid">
          <div className="info-item">
            <span className="info-label">{t('adminPanel.contractAddress')}</span>
            <span className="info-value">{medical?.address}</span>
          </div>
          <div className="info-item">
            <span className="info-label">{t('adminPanel.network')}</span>
            <span className="info-value">Localhost (31337)</span>
          </div>
          <div className="info-item">
            <span className="info-label">{t('adminPanel.yourRole')}</span>
            <span className="info-value">{t('adminPanel.administrator')}</span>
          </div>
          <div className="info-item">
            <span className="info-label">{t('adminPanel.totalUsers')}</span>
            <span className="info-value">{userStatistics.data?.total || 0}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;