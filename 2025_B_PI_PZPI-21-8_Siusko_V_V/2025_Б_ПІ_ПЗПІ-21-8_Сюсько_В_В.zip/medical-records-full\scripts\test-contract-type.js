const { ethers } = require("hardhat");

async function main() {
  console.log("🔍 Діагностика контракту...\n");
  
  // Підключаємося до деплойнутого контракту
  const contractAddress = "0x8464135c8F25Da09e49BC8782676a84730C318bC"; // Ваша адреса
  const accounts = await ethers.getSigners();
  
  try {
    const medical = await ethers.getContractAt("MedicalRecords", contractAddress);
    
    console.log("📍 Contract Address:", contractAddress);
    console.log("👥 Test Accounts:");
    console.log(`   Account[0]: ${accounts[0].address}`);
    console.log(`   Account[1]: ${accounts[1].address}`);
    console.log(`   Account[2]: ${accounts[2].address}\n`);
    
    // Тест 1: Перевірка базових функцій
    console.log("🧪 Test 1: Базові функції...");
    try {
      const recordId = await medical.getRecordId();
      console.log(`✅ getRecordId() працює: ${recordId}`);
    } catch (error) {
      console.log(`❌ getRecordId() не працює: ${error.message}`);
    }
    
    // Тест 2: Перевірка чи є функції ролей
    console.log("\n🧪 Test 2: Функції ролей...");
    try {
      const role = await medical.getUserRole(accounts[1].address);
      console.log(`✅ getUserRole() працює! Role: ${role}`);
      console.log("📋 Це НОВИЙ контракт з ролями!");
    } catch (error) {
      console.log(`❌ getUserRole() не працює: ${error.message}`);
      console.log("📋 Це БАЗОВИЙ контракт без ролей!");
    }
    
    // Тест 3: Перевірка функції додавання записів
    console.log("\n🧪 Test 3: Функція addRecord...");
    try {
      // Просто перевіряємо чи існує функція (не виконуємо)
      const addRecordFunction = medical.interface.getFunction("addRecord");
      console.log(`✅ addRecord() існує з параметрами: ${addRecordFunction.inputs.length}`);
    } catch (error) {
      console.log(`❌ addRecord() не знайдена: ${error.message}`);
    }
    
    // Тест 4: Перевірка функції createPendingRecord
    console.log("\n🧪 Test 4: Функція createPendingRecord...");
    try {
      const createPendingFunction = medical.interface.getFunction("createPendingRecord");
      console.log(`✅ createPendingRecord() існує з параметрами: ${createPendingFunction.inputs.length}`);
    } catch (error) {
      console.log(`❌ createPendingRecord() не знайдена: ${error.message}`);
    }
    
    // Тест 5: Список всіх функцій в контракті
    console.log("\n📋 Всі функції в контракті:");
    const functions = Object.keys(medical.interface.functions);
    functions.forEach(func => {
      console.log(`   - ${func}`);
    });
    
  } catch (error) {
    console.error("❌ Помилка підключення до контракту:", error.message);
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });