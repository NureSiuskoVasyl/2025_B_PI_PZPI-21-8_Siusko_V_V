import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { userRoleSelector } from "../../store/selectors";
import { useTranslation } from "react-i18next";
import "./pendingRecords.css";

const PendingRecords = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const provider = useSelector((state) => state.provider.connection);
  const medical = useSelector((state) => state.medical.contract);
  const account = useSelector((state) => state.provider.account);
  const userRole = useSelector(userRoleSelector);
  
  const [pendingRecords, setPendingRecords] = useState([]);
  const [loading, setLoading] = useState(false);
  const [rejectionReason, setRejectionReason] = useState({});

  // Завантаження pending записів
  const loadPendingRecords = async () => {
    if (!medical || !account) return;
    
    setLoading(true);
    try {
      const signer = await provider.getSigner();
      const connectedMedical = medical.connect(signer);
      
      let recordIds = [];
      
      if (userRole.isPatient) {
        // Для пацієнта - тільки його pending записи
        recordIds = await connectedMedical.getMyPendingRecords();
        console.log("Patient pending record IDs:", recordIds.map(id => id.toString()));
      } else if (userRole.isDoctor) {
        // Для лікаря - записи, які він створив
        recordIds = await connectedMedical.getDoctorPendingRecords();
        console.log("Doctor pending record IDs:", recordIds.map(id => id.toString()));
      }
      
      const records = [];
      for (let recordId of recordIds) {
        try {
          const record = await connectedMedical.getPendingRecord(recordId);
          console.log(`Loading pending record ${recordId.toString()}:`, record);
          
          records.push({
            pendingRecordId: recordId.toString(),
            timestamp: record.timestamp.toString(),
            patient: record.patient,
            doctor: record.doctor,
            name: record.name,
            age: record.age.toString(),
            gender: record.gender,
            bloodType: record.bloodType,
            allergies: record.allergies,
            diagnosis: record.diagnosis,
            treatment: record.treatment,
            status: record.status // 0=PENDING, 1=APPROVED, 2=REJECTED
          });
        } catch (error) {
          console.error(`Error loading pending record ${recordId}:`, error);
        }
      }
      
      console.log("Loaded pending records:", records);
      setPendingRecords(records);
    } catch (error) {
      console.error("Error loading pending records:", error);
    }
    setLoading(false);
  };

  // Підтвердження запису
  const approveRecord = async (pendingRecordId) => {
    if (!medical || !userRole.isPatient) return;
    
    try {
      const signer = await provider.getSigner();
      console.log(`Approving record ${pendingRecordId}...`);
      
      const tx = await medical.connect(signer).approveRecord(pendingRecordId);
      console.log("Transaction sent:", tx.hash);
      
      await tx.wait();
      console.log("✅ Record approved successfully!");
      alert(t('pendingRecords.alerts.approvedSuccess'));
      
      // Перезавантажуємо список
      await loadPendingRecords();
      
    } catch (error) {
      console.error("❌ Error approving record:", error);
      
      let errorMessage = t('pendingRecords.alerts.approveFailed');
      if (error.message.includes("You can only approve your own records")) {
        errorMessage = t('pendingRecords.alerts.onlyOwnRecords');
      } else if (error.reason) {
        errorMessage = error.reason;
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      alert(`❌ ${t('pendingRecords.alerts.error')} ${errorMessage}`);
    }
  };

  // Відхилення запису
  const rejectRecord = async (pendingRecordId, reason) => {
    if (!medical || !userRole.isPatient) return;
    
    if (!reason || reason.trim() === "") {
      alert(t('pendingRecords.alerts.provideReason'));
      return;
    }
    
    try {
      const signer = await provider.getSigner();
      console.log(`Rejecting record ${pendingRecordId} with reason: ${reason}`);
      
      const tx = await medical.connect(signer).rejectRecord(pendingRecordId, reason);
      console.log("Transaction sent:", tx.hash);
      
      await tx.wait();
      console.log("✅ Record rejected successfully!");
      alert(t('pendingRecords.alerts.rejectedSuccess'));
      
      // Очищуємо поле причини
      setRejectionReason(prev => ({ ...prev, [pendingRecordId]: "" }));
      
      // Перезавантажуємо список
      await loadPendingRecords();
      
    } catch (error) {
      console.error("❌ Error rejecting record:", error);
      
      let errorMessage = t('pendingRecords.alerts.rejectFailed');
      if (error.message.includes("You can only reject your own records")) {
        errorMessage = t('pendingRecords.alerts.onlyOwnRecords');
      } else if (error.reason) {
        errorMessage = error.reason;
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      alert(`❌ ${t('pendingRecords.alerts.error')} ${errorMessage}`);
    }
  };

  // Завантажуємо записи при зміні ролі або аккаунта
  useEffect(() => {
    if (medical && account && userRole.isRegistered) {
      loadPendingRecords();
    }
  }, [medical, account, userRole.role]);

  // Функція для форматування дати
  const formatTimestamp = (timestamp) => {
    const date = new Date(parseInt(timestamp) * 1000);
    return date.toLocaleString('uk-UA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Функція для отримання статусу
  const getStatusDisplay = (status) => {
    const statuses = {
      0: { text: t('pendingRecords.statusPending'), class: "status-pending" },
      1: { text: t('pendingRecords.statusApproved'), class: "status-approved" },
      2: { text: t('pendingRecords.statusRejected'), class: "status-rejected" }
    };
    return statuses[status] || { text: t('pendingRecords.statusUnknown'), class: "status-unknown" };
  };

  if (!account) {
    return (
      <div className="pending-records-container">
        <h1>{t('pendingRecords.connectWallet')}</h1>
        <p>{t('pendingRecords.connectWalletText')}</p>
      </div>
    );
  }

  if (!userRole.isRegistered) {
    return (
      <div className="pending-records-container">
        <h1>{t('pendingRecords.registrationRequired')}</h1>
        <p>{t('pendingRecords.registrationText')}</p>
        <p>{t('pendingRecords.currentRole')} <strong>{userRole.role}</strong></p>
      </div>
    );
  }

  return (
    <div className="pending-records-container">
      <div className="pending-header">
        {userRole.isPatient && (
          <div className="patient-header">
            <h1>{t('pendingRecords.title')}</h1>
            <p>{t('pendingRecords.patient')} {account.slice(0, 6)}...{account.slice(-4)}</p>
            <p className="info-note">{t('pendingRecords.patientSubtitle')}</p>
          </div>
        )}
        
        {userRole.isDoctor && (
          <div className="doctor-header">
            <h1>{t('pendingRecords.doctorTitle')}</h1>
            <p>{t('pendingRecords.doctor')} {account.slice(0, 6)}...{account.slice(-4)}</p>
            <p className="info-note">{t('pendingRecords.doctorSubtitle')}</p>
          </div>
        )}
        
        <button 
          onClick={loadPendingRecords} 
          disabled={loading}
          className="refresh-btn"
        >
          {loading ? t('pendingRecords.loading') : t('pendingRecords.refresh')}
        </button>
      </div>

      {loading ? (
        <div className="loading">{t('pendingRecords.loading')}</div>
      ) : pendingRecords.length === 0 ? (
        <div className="no-records">
          {userRole.isPatient ? (
            <div>
              <h2>{t('pendingRecords.noRecords')}</h2>
              <p>{t('pendingRecords.patientNoRecords')}</p>
            </div>
          ) : (
            <div>
              <h2>{t('pendingRecords.noRecords')}</h2>
              <p>{t('pendingRecords.doctorNoRecords')}</p>
            </div>
          )}
        </div>
      ) : (
        <div className="records-list">
          {pendingRecords.map((record, index) => {
            const statusInfo = getStatusDisplay(record.status);
            return (
              <div key={record.pendingRecordId} className="pending-record-card">
                <div className="record-header">
                  <h3>{t('pendingRecords.recordNumber')}{record.pendingRecordId}</h3>
                  <span className={`status-badge ${statusInfo.class}`}>
                    {statusInfo.text}
                  </span>
                </div>
                
                <div className="record-info">
                  <div className="record-meta">
                    <p><strong>{t('pendingRecords.date')}</strong> {formatTimestamp(record.timestamp)}</p>
                    <p><strong>{t('pendingRecords.patient')}</strong> {record.patient.slice(0, 6)}...{record.patient.slice(-4)}</p>
                    <p><strong>{t('pendingRecords.doctor')}</strong> {record.doctor.slice(0, 6)}...{record.doctor.slice(-4)}</p>
                  </div>
                  
                  <div className="record-details">
                    <div className="detail-row">
                      <span className="label">{t('pendingRecords.patientName')}</span>
                      <span className="value">{record.name}</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">{t('pendingRecords.age')}</span>
                      <span className="value">{record.age} {t('pendingRecords.years')}</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">{t('pendingRecords.gender')}</span>
                      <span className="value">{record.gender}</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">{t('pendingRecords.bloodType')}</span>
                      <span className="value">{record.bloodType}</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">{t('pendingRecords.allergies')}</span>
                      <span className="value">{record.allergies}</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">{t('pendingRecords.diagnosis')}</span>
                      <span className="value highlight">{record.diagnosis}</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">{t('pendingRecords.treatment')}</span>
                      <span className="value highlight">{record.treatment}</span>
                    </div>
                  </div>
                </div>
                
                {userRole.isPatient && record.status === 0 && (
                  <div className="action-section">
                    <h4>{t('pendingRecords.patientActions')}</h4>
                    <div className="action-buttons">
                      <button 
                        onClick={() => approveRecord(record.pendingRecordId)}
                        className="approve-btn"
                      >
                        {t('pendingRecords.approveRecord')}
                      </button>
                      
                      <div className="reject-section">
                        <input
                          type="text"
                          placeholder={t('pendingRecords.rejectReason')}
                          value={rejectionReason[record.pendingRecordId] || ""}
                          onChange={(e) => setRejectionReason(prev => ({
                            ...prev,
                            [record.pendingRecordId]: e.target.value
                          }))}
                          className="reject-reason-input"
                        />
                        <button 
                          onClick={() => rejectRecord(record.pendingRecordId, rejectionReason[record.pendingRecordId])}
                          className="reject-btn"
                        >
                          {t('pendingRecords.reject')}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
                
                {userRole.isDoctor && (
                  <div className="doctor-note">
                    <p><strong>{t('pendingRecords.doctorNote')}</strong> {t('pendingRecords.waitingApproval')}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
      
      {pendingRecords.length > 0 && (
        <div className="summary">
          <p><strong>{t('pendingRecords.totalPending')}</strong> {pendingRecords.length}</p>
          <p><strong>{t('pendingRecords.pendingApproval')}</strong> {pendingRecords.filter(r => r.status === 0).length}</p>
          <p><strong>{t('pendingRecords.approved')}</strong> {pendingRecords.filter(r => r.status === 1).length}</p>
          <p><strong>{t('pendingRecords.rejected')}</strong> {pendingRecords.filter(r => r.status === 2).length}</p>
        </div>
      )}
    </div>
  );
};

export default PendingRecords;