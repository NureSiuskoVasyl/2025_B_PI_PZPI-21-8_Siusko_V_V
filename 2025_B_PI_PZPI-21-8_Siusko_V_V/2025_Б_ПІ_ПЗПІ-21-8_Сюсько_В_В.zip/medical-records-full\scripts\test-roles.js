const { ethers } = require("hardhat");

async function main() {
  console.log("👑 Тестування ролей...\n");
  
  const contractAddress = "0x8464135c8F25Da09e49BC8782676a84730C318bC";
  const accounts = await ethers.getSigners();
  
  try {
    const medical = await ethers.getContractAt("MedicalRecords", contractAddress);
    
    // Перевіряємо ролі всіх аккаунтів
    console.log("🔍 Перевірка ролей:");
    for (let i = 0; i < 3; i++) {
      try {
        const role = await medical.getUserRole(accounts[i].address);
        const roleText = ["NONE", "PATIENT", "DOCTOR", "ADMIN"][role.toString()];
        console.log(`Account[${i}] (${accounts[i].address}): ${roleText} (${role})`);
      } catch (error) {
        console.log(`Account[${i}]: Помилка - ${error.message}`);
      }
    }
    
    // Перевіряємо чи є адмін в контракті
    console.log("\n🔍 Перевірка адміна:");
    try {
      const admin = await medical.admin();
      console.log(`Admin address: ${admin}`);
    } catch (error) {
      console.log(`Не вдалося знайти адміна: ${error.message}`);
    }
    
  } catch (error) {
    console.error("❌ Помилка:", error.message);
  }
}

main().catch(console.error);