import { Route, Routes } from "react-router-dom";
import "../App.css";
import Data from "./Data/Data";
import Form from "./Form/Form";
import Navbar from "./Navbar/Navbar";
import Option from "./Option/Option";
import AdminPanel from "./AdminPanel/AdminPanel";
import PatientRegistration from "./PatientRegistration/PatientRegistration";
import PendingRecords from "./PendingRecords/PendingRecords";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import {
  loadAccount,
  loadAllData,
  loadMedical,
  loadNetwork,
  loadProvider,
  loadUserRole,
  subscribeToEvents,
} from "../store/interactions";
import config from "../config.json";
import Alert from "./Alert/Alert";

function App() {
  const dispatch = useDispatch();
  
  const loadBlockchainData = async () => {
    try {
      // 1. Завантажуємо провайдер
      const provider = loadProvider(dispatch);
      
      // 2. Завантажуємо мережу
      const chainId = await loadNetwork(provider, dispatch);
      
      // 3. Перевіряємо чи є конфігурація для цієї мережі
      if (!config[chainId] || !config[chainId].medical) {
        console.error(`No configuration found for chainId: ${chainId}`);
        return;
      }
      
      const medical_config = config[chainId].medical;
      
      // 4. Завантажуємо контракт
      const medical = loadMedical(provider, medical_config.address, dispatch);
      
      // 5. Завантажуємо аккаунт та роль
      const account = await loadAccount(provider, dispatch);
      if (account && medical) {
        await loadUserRole(medical, account, dispatch);
      }
      
      // 6. Налаштовуємо обробники подій
      if (window.ethereum) {
        window.ethereum.on("accountsChanged", async () => {
          const newAccount = await loadAccount(provider, dispatch);
          if (newAccount && medical) {
            await loadUserRole(medical, newAccount, dispatch);
          }
        });
        
        window.ethereum.on("chainChanged", () => {
          window.location.reload();
        });
      }
      
      // 7. Завантажуємо всі дані (для сумісності)
      await loadAllData(provider, medical, dispatch);
      
      // 8. Підписуємося на події
      subscribeToEvents(medical, dispatch);
      
    } catch (error) {
      console.error("Failed to load blockchain data:", error);
    }
  };
  
  useEffect(() => {
    loadBlockchainData();
  }, []);
  
  return (
    <div className="App">
      <div className="navbar">
        <Navbar />
        <Option />
        <Routes>
          <Route path="/" exact element={<Form />} />
          <Route path="/data" element={<Data />} />
          <Route path="/pending" element={<PendingRecords />} /> {/* ✅ ДОДАНО */}
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/register" element={<PatientRegistration />} />
        </Routes>
        <Alert />
      </div>
    </div>
  );
}

export default App;