require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

const privateKeys = process.env.PRIVATE_KEYS || "";
const goerliApiKey = process.env.GOERLI_API_KEY || "";
const mumbaiApiKey = process.env.MUMBAI_API_KEY || "";

module.exports = {
  solidity: "0.8.18",
  networks: {
    localhost: {
      url: "http://127.0.0.1:8545"
    },
    hardhat: {
      // Вбудована мережа Hardhat
    },
    // Зовнішні мережі тільки якщо є ключі
    ...(goerliApiKey && privateKeys ? {
      goerli: {
        url: goerliApiKey,
        accounts: privateKeys.split(","),
      }
    } : {}),
    ...(mumbaiApiKey && privateKeys ? {
      mumbai: {
        url: mumbaiApiKey,
        accounts: privateKeys.split(","),
      }
    } : {}),
  },
};