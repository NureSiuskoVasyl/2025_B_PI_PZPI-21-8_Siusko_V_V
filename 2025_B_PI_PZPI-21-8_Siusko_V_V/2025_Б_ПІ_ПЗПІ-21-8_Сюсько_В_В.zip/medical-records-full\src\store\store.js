import { createStore, combineReducers, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import { composeWithDevTools } from "redux-devtools-extension";

/* Import Reducers */
import { provider, medical } from "./reducer";

const reducer = combineReducers({ provider, medical });

const initialState = {};

const middleware = [thunk];

const store = createStore(
  reducer,
  initialState,
  composeWithDevTools(applyMiddleware(...middleware))
);

// Додаємо store до window для доступу з консолі
if (typeof window !== 'undefined') {
  window.store = store;
}

export default store;