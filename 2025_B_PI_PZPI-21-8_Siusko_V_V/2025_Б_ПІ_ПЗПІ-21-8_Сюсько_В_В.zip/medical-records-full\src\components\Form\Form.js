import React, { useState, useEffect } from "react";
import "./form.css";
import { submitRecord } from "../../store/interactions";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { userRoleSelector } from "../../store/selectors";

const Form = () => {
  const { t } = useTranslation();
  const provider = useSelector((state) => state.provider.connection);
  const medical = useSelector((state) => state.medical.contract);
  const account = useSelector((state) => state.provider.account);
  const userRole = useSelector(userRoleSelector);
  const dispatch = useDispatch();

  const [patientAddress, setPatientAddress] = useState("");
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [bloodType, setBloodType] = useState("");
  const [allergies, setAllergies] = useState("");
  const [diagnosis, setDiagnosis] = useState("");
  const [treatment, setTreatment] = useState("");
  
  // Додаємо стани для діагностики
  const [debugInfo, setDebugInfo] = useState(null);
  const [patientRoleInfo, setPatientRoleInfo] = useState(null);

  // Функція для перевірки ролі користувача
  const checkUserRole = async (address) => {
    if (!medical || !address) return null;
    
    try {
      const role = await medical.getUserRole(address);
      const isRegistered = await medical.isUserRegistered(address);
      const roleNames = ["NONE", "PATIENT", "DOCTOR", "ADMIN"];
      
      return {
        role: roleNames[role.toNumber ? role.toNumber() : role],
        isRegistered
      };
    } catch (error) {
      console.error("Error checking role:", error);
      return { role: "ERROR", isRegistered: false };
    }
  };

  // Перевіряємо роль поточного користувача при завантаженні
  useEffect(() => {
    if (medical && account) {
      checkUserRole(account).then(setDebugInfo);
    }
  }, [medical, account]);

  // Перевіряємо роль пацієнта при зміні адреси
  useEffect(() => {
    if (medical && patientAddress && patientAddress.match(/^0x[a-fA-F0-9]{40}$/)) {
      checkUserRole(patientAddress).then(setPatientRoleInfo);
    } else {
      setPatientRoleInfo(null);
    }
  }, [medical, patientAddress]);

  const submitHandler = async (e) => {
    e.preventDefault();
    
    // Детальна діагностика
    console.log("=== FORM SUBMISSION DEBUG ===");
    console.log("Account:", account);
    console.log("User role from selector:", userRole);
    console.log("Debug info:", debugInfo);
    console.log("Patient address:", patientAddress);
    console.log("Patient role info:", patientRoleInfo);

    // Перевірка чи користувач лікар
    if (!userRole.isDoctor) {
      alert(`${t('form.accessDenied')} ${t('form.currentRole')} ${userRole.role}. ${t('form.onlyDoctors')}`);
      return;
    }

    // Перевірка чи всі поля заповнені
    if (!patientAddress || !name || !age || !gender || !bloodType || !allergies || !diagnosis || !treatment) {
      alert("Please fill all fields!");
      return;
    }

    // Перевірка валідності адреси пацієнта
    if (!patientAddress.match(/^0x[a-fA-F0-9]{40}$/)) {
      alert("Please enter valid patient Ethereum address!");
      return;
    }

    // Перевірка чи адреса пацієнта зареєстрована
    if (!patientRoleInfo) {
      alert("Please wait while we verify the patient address...");
      return;
    }

    if (patientRoleInfo.role !== "PATIENT") {
      alert(`Error: Target address is not a registered patient. Their role: ${patientRoleInfo.role}`);
      return;
    }

    try {
      console.log("Calling submitRecord...");
      
      await submitRecord(
        patientAddress,
        name,
        age,
        gender,
        bloodType,
        allergies,
        diagnosis,
        treatment,
        provider,
        medical,
        dispatch
      );

      // Очищення форми тільки при успіху
      setPatientAddress("");
      setName("");
      setAge("");
      setGender("");
      setBloodType("");
      setAllergies("");
      setDiagnosis("");
      setTreatment("");
      setPatientRoleInfo(null);
      
      alert("✅ Pending record created! The patient needs to approve it.");
      
    } catch (error) {
      console.error("Form submission error:", error);
      alert(`Error: ${error.message}`);
    }
  };

  const quickPatientAddresses = [
    {
      name: t('form.quickPatients.account0'),
      address: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",
    },
    {
      name: t('form.quickPatients.account3'), 
      address: "0x90F79bf6EB2c4f870365E785982E1f101E93b906",
    },
    {
      name: t('form.quickPatients.account4'),
      address: "0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65",
    }
  ];

  // Показувати форму тільки лікарям
  if (!account) {
    return (
      <div className="login-container">
        <h1>{t('form.connectWallet')}</h1>
      </div>
    );
  }

  return (
    <div className="login-container">
      {/* Діагностична інформація */}
      {debugInfo && (
        <div style={{ 
          backgroundColor: debugInfo.role === "DOCTOR" ? "#d4edda" : "#f8d7da", 
          padding: "10px", 
          borderRadius: "5px", 
          marginBottom: "20px",
          border: debugInfo.role === "DOCTOR" ? "1px solid #c3e6cb" : "1px solid #f5c6cb"
        }}>
          <strong>{t('form.debugInfo')}</strong><br/>
          {t('form.account')}: {account.slice(0, 6)}...{account.slice(-4)}<br/>
          {t('form.role')}: {debugInfo.role}<br/>
          {t('form.registered')}: {debugInfo.isRegistered ? "✅" : "❌"}<br/>
          {t('form.canAddRecords')}: {debugInfo.role === "DOCTOR" ? "✅" : "❌"}
        </div>
      )}

      {!userRole.isDoctor ? (
        <div>
          <h1>{t('form.accessDenied')}</h1>
          <p>{t('form.onlyDoctors')}</p>
          <p>{t('form.currentRole')}: <strong>{userRole.role}</strong></p>
          {userRole.isNone && !userRole.isRegistered && (
            <p>{t('form.registerFirst')}</p>
          )}
          {debugInfo && debugInfo.role === "NONE" && (
            <div style={{ marginTop: "20px", padding: "15px", backgroundColor: "#fff3cd", borderRadius: "5px" }}>
              <strong>{t('form.testingNote')}</strong><br/>
              {t('form.testingHelper')}
            </div>
          )}
        </div>
      ) : (
        <form onSubmit={submitHandler}>
          <h1>{t('form.title')}</h1>
          <p className="doctor-info">{t('form.doctorInfo')} {account?.slice(0, 6)}...{account?.slice(-4)}</p>

          {/* Адреса пацієнта */}
          <label htmlFor="patientAddress">{t('form.patientAddress')}</label>
          <input
            type="text"
            id="patientAddress"
            name="patientAddress"
            value={patientAddress}
            onChange={(e) => setPatientAddress(e.target.value)}
            required
            placeholder={t('form.placeholders.patientAddress')}
            className="address-input"
          />

          {/* Інформація про пацієнта */}
          {patientRoleInfo && (
            <div style={{ 
              backgroundColor: patientRoleInfo.role === "PATIENT" ? "#d4edda" : "#f8d7da", 
              padding: "8px", 
              borderRadius: "4px", 
              marginBottom: "15px",
              fontSize: "14px",
              border: patientRoleInfo.role === "PATIENT" ? "1px solid #c3e6cb" : "1px solid #f5c6cb"
            }}>
              {t('form.patientRole')}: <strong>{patientRoleInfo.role}</strong> | 
              {t('form.registered')}: {patientRoleInfo.isRegistered ? "✅" : "❌"} |
              {t('form.canReceiveRecords')}: {patientRoleInfo.role === "PATIENT" ? "✅" : "❌"}
            </div>
          )}

          {/* Швидкий вибір тестових пацієнтів */}
          <div className="quick-select">
            <label>{t('form.quickSelect')}</label>
            <div className="quick-buttons">
              {quickPatientAddresses.map((patient, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => setPatientAddress(patient.address)}
                  className="quick-patient-btn"
                >
                  {patient.name}
                </button>
              ))}
            </div>
          </div>

          <label htmlFor="name">{t('form.patientName')}</label>
          <input
            type="text"
            id="name"
            name="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            placeholder={t('form.placeholders.patientName')}
          />

          <label htmlFor="age">{t('form.age')}</label>
          <input
            type="number"
            id="age"
            name="age"
            required
            placeholder={t('form.placeholders.age')}
            value={age}
            onChange={(e) => setAge(e.target.value)}
          />

          <label htmlFor="gender">{t('form.gender')}</label>
          <select
            id="gender"
            name="gender"
            required
            onChange={(e) => setGender(e.target.value)}
            value={gender}
          >
            <option value="">{t('form.selectGender')}</option>
            <option value="Male">{t('form.male')}</option>
            <option value="Female">{t('form.female')}</option>
            <option value="Other">{t('form.other')}</option>
          </select>

          <label htmlFor="bloodType">{t('form.bloodType')}</label>
          <input
            type="text"
            id="bloodType"
            name="bloodType"
            required
            placeholder={t('form.placeholders.bloodType')}
            value={bloodType}
            onChange={(e) => setBloodType(e.target.value)}
          />

          <label htmlFor="allergies">{t('form.allergies')}</label>
          <input
            type="text"
            id="allergies"
            name="allergies"
            required
            placeholder={t('form.placeholders.allergies')}
            value={allergies}
            onChange={(e) => setAllergies(e.target.value)}
          />

          <label htmlFor="diagnosis">{t('form.diagnosis')}</label>
          <input
            type="text"
            id="diagnosis"
            name="diagnosis"
            required
            placeholder={t('form.placeholders.diagnosis')}
            value={diagnosis}
            onChange={(e) => setDiagnosis(e.target.value)}
          />

          <label htmlFor="treatment">{t('form.treatment')}</label>
          <input
            type="text"
            id="treatment"
            name="treatment"
            required
            placeholder={t('form.placeholders.treatment')}
            value={treatment}
            onChange={(e) => setTreatment(e.target.value)}
          />

          <input 
            type="submit" 
            value={t('form.createRecord')} 
            disabled={!patientRoleInfo || patientRoleInfo.role !== "PATIENT"}
          />
          
          {patientAddress && patientRoleInfo && patientRoleInfo.role !== "PATIENT" && (
            <p style={{ color: "red", fontSize: "14px", marginTop: "10px" }}>
              {t('form.addressWarning')}
            </p>
          )}
        </form>
      )}
    </div>
  );
};

export default Form;