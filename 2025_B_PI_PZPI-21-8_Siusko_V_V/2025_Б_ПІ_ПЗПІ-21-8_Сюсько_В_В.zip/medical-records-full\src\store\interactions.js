import { ethers } from "ethers";
import MEDICAL_CONTRACT from "../abis/MedicalRecords.json";
const MEDICAL_ABI = MEDICAL_CONTRACT.abi;

export const loadProvider = (dispatch) => {
  const connection = new ethers.providers.Web3Provider(window.ethereum);
  dispatch({ type: "PROVIDER_LOADED", connection });
  return connection;
};

export const loadNetwork = async (provider, dispatch) => {
  const { chainId } = await provider.getNetwork();
  dispatch({ type: "NETWORK_LOADED", chainId });
  return chainId;
};

export const loadAccount = async (provider, dispatch) => {
  const accounts = await window.ethereum.request({
    method: "eth_requestAccounts",
  });
  const account = ethers.utils.getAddress(accounts[0]);
  dispatch({ type: "ACCOUNT_LOADED", account });
  let balance = await provider.getBalance(account);
  balance = ethers.utils.formatEther(balance);
  dispatch({ type: "ETHER_BALANCE_LOADED", balance });
  return account;
};

export const loadMedical = (provider, address, dispatch) => {
  const medical = new ethers.Contract(address, MEDICAL_ABI, provider);
  dispatch({ type: "MEDICAL_LOADED", medical });
  return medical;
};

// === ФУНКЦІЇ ДЛЯ РОЛЕЙ ===

export const loadUserRole = async (medical, account, dispatch) => {
  try {
    const role = await medical.getUserRole(account);
    const isRegistered = await medical.isUserRegistered(account);
    
    const roleNames = ["NONE", "PATIENT", "DOCTOR", "ADMIN"];
    const userRole = roleNames[role] || "NONE";
    
    dispatch({ 
      type: "USER_ROLE_LOADED", 
      userRole, 
      isRegistered 
    });
    
    return { userRole, isRegistered };
  } catch (error) {
    console.error("Error loading user role:", error);
    dispatch({ type: "USER_ROLE_FAILED" });
  }
};

export const registerAsPatient = async (medical, provider, dispatch) => {
  let transaction;
  dispatch({ type: "PATIENT_REGISTRATION_PENDING" });
  try {
    const signer = await provider.getSigner();
    transaction = await medical.connect(signer).registerAsPatient();
    await transaction.wait();
    
    dispatch({ type: "PATIENT_REGISTRATION_SUCCESS" });
    
    const account = await signer.getAddress();
    await loadUserRole(medical, account, dispatch);
    
  } catch (error) {
    console.error("Patient registration failed:", error);
    dispatch({ type: "PATIENT_REGISTRATION_FAILED" });
  }
};

export const assignDoctor = async (medical, doctorAddress, provider, dispatch) => {
  let transaction;
  dispatch({ type: "DOCTOR_ASSIGNMENT_PENDING" });
  try {
    const signer = await provider.getSigner();
    transaction = await medical.connect(signer).assignDoctor(doctorAddress);
    await transaction.wait();
    
    dispatch({ type: "DOCTOR_ASSIGNMENT_SUCCESS" });
  } catch (error) {
    console.error("Doctor assignment failed:", error);
    dispatch({ type: "DOCTOR_ASSIGNMENT_FAILED" });
  }
};

// === ВИПРАВЛЕНА ФУНКЦІЯ ДОДАВАННЯ ЗАПИСІВ ===

export const submitRecord = async (
  patientAddress,
  name,
  age,
  gender,
  bloodType,
  allergies,
  diagnosis,
  treatment,
  provider,
  medical,
  dispatch
) => {
  let transaction;
  dispatch({ type: "NEW_RECORD_LOADED" });
  
  try {
    const signer = await provider.getSigner();
    
    console.log("Creating pending record with data:", {
      patientAddress,
      name,
      age,
      gender,
      bloodType,
      allergies,
      diagnosis,
      treatment
    });
    
    // Використовуємо createPendingRecord замість старого addRecord
    transaction = await medical
      .connect(signer)
      .createPendingRecord(
        patientAddress,
        name,
        parseInt(age), // Переконуємося що age це число
        gender,
        bloodType,
        allergies,
        diagnosis,
        treatment
      );

    await transaction.wait();
    console.log("✅ Pending record created successfully");
    
    dispatch({ type: "NEW_RECORD_SUCCESS" });
    
  } catch (error) {
    console.error("❌ Create pending record failed:", error);
    
    // Обробка специфічних помилок
    let errorMessage = "Failed to create record";
    
    if (error.message.includes("Only doctor can perform this action")) {
      errorMessage = "Only doctors can create medical records. Please contact admin to assign doctor role.";
    } else if (error.message.includes("Target address is not a registered patient")) {
      errorMessage = "The target address is not a registered patient. Patient must register first.";
    } else if (error.message.includes("Invalid patient address")) {
      errorMessage = "Invalid patient address provided.";
    } else if (error.reason) {
      errorMessage = error.reason;
    }
    
    alert(errorMessage);
    dispatch({ type: "NEW_RECORD_FAIL" });
  }
};

// === ФУНКЦІЇ ДЛЯ ОТРИМАННЯ ЗАПИСІВ ===

export const loadMyRecords = async (medical, dispatch) => {
  try {
    const provider = medical.provider;
    const signer = provider.getSigner();
    const connectedMedical = medical.connect(signer);
    
    const myRecordIds = await connectedMedical.getMyRecords();
    const myRecords = [];
    
    for (let recordId of myRecordIds) {
      try {
        const record = await connectedMedical.getRecord(recordId);
        myRecords.push({
          recordId: recordId.toString(),
          timestamp: record.timestamp.toString(),
          patient: record.patient,
          doctor: record.doctor,
          name: record.name,
          age: record.age.toString(),
          gender: record.gender,
          bloodType: record.bloodType,
          allergies: record.allergies,
          diagnosis: record.diagnosis,
          treatment: record.treatment
        });
      } catch (error) {
        console.error(`Error loading record ${recordId}:`, error);
      }
    }
    
    dispatch({ type: "MY_RECORDS_LOADED", myRecords });
  } catch (error) {
    console.error("Error loading my records:", error);
    dispatch({ type: "MY_RECORDS_FAILED" });
  }
};

export const loadAllRecords = async (medical, dispatch) => {
  try {
    const provider = medical.provider;
    const signer = provider.getSigner();
    const connectedMedical = medical.connect(signer);
    
    const recordIds = await connectedMedical.getAllRecords();
    const allRecords = [];
    
    for (let recordId of recordIds) {
      try {
        const record = await connectedMedical.getRecord(recordId);
        allRecords.push({
          recordId: recordId.toString(),
          timestamp: record.timestamp.toString(),
          patient: record.patient,
          doctor: record.doctor,
          name: record.name,
          age: record.age.toString(),
          gender: record.gender,
          bloodType: record.bloodType,
          allergies: record.allergies,
          diagnosis: record.diagnosis,
          treatment: record.treatment
        });
      } catch (error) {
        console.error(`Error loading record ${recordId}:`, error);
      }
    }
    
    dispatch({ type: "ALL_RECORDS_LOADED", allRecords });
  } catch (error) {
    console.error("Error loading all records:", error);
    dispatch({ type: "ALL_RECORDS_FAILED" });
  }
};

// === ФУНКЦІЯ ВИДАЛЕННЯ (без змін) ===

export const deleteData = async (medical, recordId, dispatch, provider) => {
  let transaction;
  dispatch({ type: "DELETE_REQUEST_INNITIALIZED" });
  try {
    const signer = await provider.getSigner();
    transaction = await medical.connect(signer).deleteRecord(recordId);
    await transaction.wait();
  } catch (error) {
    console.error("Delete record failed:", error);
    dispatch({ type: "DELETE_REQUEST_FAILED" });
  }
};

// === СТАРА ФУНКЦІЯ (залишаємо для сумісності) ===

export const loadAllData = async (provider, medical, dispatch) => {
  // Ця функція може не працювати з новим контрактом
  // але залишаємо для сумісності зі старим кодом
  try {
    const block = await provider.getBlockNumber();
    const medicalStream = await medical.queryFilter(
      "MedicalRecords__AddRecord",
      0,
      block
    );
    const medicalRecords = medicalStream.map((event) => event.args);
    dispatch({ type: "ALL_MEDICAL_RECORDS", medicalRecords });
    
    const deleteStream = await medical.queryFilter(
      "MedicalRecords__DeleteRecord",
      0,
      block
    );
    const deleteRecords = deleteStream.map((event) => event.args);
    dispatch({ type: "ALL_DELETED_RECORDS", deleteRecords });
  } catch (error) {
    console.error("Error loading old data format:", error);
  }
};

// === EVENT LISTENERS ===

export const subscribeToEvents = async (medical, dispatch) => {
  try {
    // Події для записів
    medical.on("RecordPending", (pendingRecordId, timestamp, patient, doctor, name, event) => {
      console.log("New pending record:", { pendingRecordId: pendingRecordId.toString(), patient, doctor, name });
      dispatch({ type: "RECORD_PENDING", event });
    });
    
    medical.on("RecordApproved", (pendingRecordId, finalRecordId, patient, doctor, event) => {
      console.log("Record approved:", { pendingRecordId: pendingRecordId.toString(), finalRecordId: finalRecordId.toString() });
      dispatch({ type: "RECORD_APPROVED", event });
    });
    
    medical.on("MedicalRecords__AddRecord", (...args) => {
      const event = args[args.length - 1];
      const medicalOrder = event.args;
      dispatch({ type: "NEW_RECORD_SUCCESS", medicalOrder, event });
    });
    
    medical.on("MedicalRecords__DeleteRecord", (...args) => {
      const event = args[args.length - 1];
      const deleteOrder = event.args;
      dispatch({ type: "DELETE_REQUEST_SUCCESS", deleteOrder, event });
    });
    
    // Події для користувачів
    medical.on("UserRegistered", (user, role, event) => {
      console.log("User registered:", { user, role: role.toString() });
      dispatch({ type: "USER_REGISTERED", user, role: role.toString(), event });
    });
    
    medical.on("DoctorAssigned", (doctor, admin, event) => {
      console.log("Doctor assigned:", { doctor, admin });
      dispatch({ type: "DOCTOR_ASSIGNED", doctor, admin, event });
    });
    
    console.log("✅ Event listeners successfully attached");
    
  } catch (error) {
    console.error("Error setting up event listeners:", error);
  }
};

// Функція для отримання всіх користувачів за подіями
export const loadAllUsers = async (medical, provider, dispatch) => {
  try {
    dispatch({ type: "USERS_LOADING" });
    
    const block = await provider.getBlockNumber();
    
    // Отримуємо всі події реєстрації користувачів
    const userRegisteredEvents = await medical.queryFilter(
      "UserRegistered",
      0,
      block
    );
    
    const doctorAssignedEvents = await medical.queryFilter(
      "DoctorAssigned", 
      0,
      block
    );
    
    const users = [];
    
    // Обробляємо події реєстрації
    for (const event of userRegisteredEvents) {
      const userAddress = event.args.user;
      const role = event.args.role;
      
      try {
        // Перевіряємо поточний статус користувача
        const currentRole = await medical.getUserRole(userAddress);
        const isRegistered = await medical.isUserRegistered(userAddress);
        
        // Отримуємо баланс
        const balance = await provider.getBalance(userAddress);
        
        const roleNames = ["NONE", "PATIENT", "DOCTOR", "ADMIN"];
        
        users.push({
          address: userAddress,
          role: roleNames[currentRole],
          originalRole: roleNames[role], // Роль при реєстрації
          isRegistered,
          balance: ethers.utils.formatEther(balance),
          registrationBlock: event.blockNumber,
          registrationTx: event.transactionHash
        });
      } catch (error) {
        console.error(`Error loading user ${userAddress}:`, error);
      }
    }
    
    // Додаємо інформацію про призначення лікарів
    const doctorAssignments = {};
    for (const event of doctorAssignedEvents) {
      doctorAssignments[event.args.doctor] = {
        assignedBy: event.args.admin,
        assignmentBlock: event.blockNumber,
        assignmentTx: event.transactionHash
      };
    }
    
    // Додаємо інформацію про призначення до користувачів
    const usersWithAssignments = users.map(user => ({
      ...user,
      doctorAssignment: user.role === "DOCTOR" ? doctorAssignments[user.address] : null
    }));
    
    dispatch({ 
      type: "ALL_USERS_LOADED", 
      users: usersWithAssignments 
    });
    
    return usersWithAssignments;
    
  } catch (error) {
    console.error("Error loading all users:", error);
    dispatch({ type: "USERS_LOADING_FAILED" });
    return [];
  }
};

// Функція для отримання статистики користувачів
export const loadUserStatistics = async (medical, provider, dispatch) => {
  try {
    const users = await loadAllUsers(medical, provider, dispatch);
    
    const statistics = {
      total: users.length,
      admins: users.filter(u => u.role === "ADMIN").length,
      doctors: users.filter(u => u.role === "DOCTOR").length,
      patients: users.filter(u => u.role === "PATIENT").length,
      inactive: users.filter(u => u.role === "NONE").length,
      registered: users.filter(u => u.isRegistered).length
    };
    
    dispatch({ type: "USER_STATISTICS_LOADED", statistics });
    return statistics;
    
  } catch (error) {
    console.error("Error loading user statistics:", error);
    return null;
  }
};

// Функція для видалення лікаря (тільки для адміна)
export const removeDoctorRole = async (medical, doctorAddress, provider, dispatch) => {
  let transaction;
  dispatch({ type: "DOCTOR_REMOVAL_PENDING" });
  
  try {
    const signer = await provider.getSigner();
    transaction = await medical.connect(signer).removeDoctor(doctorAddress);
    await transaction.wait();
    
    dispatch({ type: "DOCTOR_REMOVAL_SUCCESS", doctorAddress });
    console.log(`✅ Doctor ${doctorAddress} removed successfully`);
    
    // Перезавантажуємо список користувачів
    await loadAllUsers(medical, provider, dispatch);
    
  } catch (error) {
    console.error("❌ Doctor removal failed:", error);
    dispatch({ type: "DOCTOR_REMOVAL_FAILED" });
    
    let errorMessage = "Failed to remove doctor";
    if (error.message.includes("Only admin can perform this action")) {
      errorMessage = "Only admin can remove doctors";
    } else if (error.message.includes("User is not a doctor")) {
      errorMessage = "User is not a doctor";
    } else if (error.reason) {
      errorMessage = error.reason;
    }
    
    throw new Error(errorMessage);
  }
};

// Функція для отримання детальної інформації про користувача
export const getUserDetails = async (medical, userAddress, provider) => {
  try {
    const role = await medical.getUserRole(userAddress);
    const isRegistered = await medical.isUserRegistered(userAddress);
    const balance = await provider.getBalance(userAddress);
    
    const roleNames = ["NONE", "PATIENT", "DOCTOR", "ADMIN"];
    
    let additionalInfo = {};
    
    // Додаткова інформація для пацієнтів
    if (role === 1) { // PATIENT
      try {
        const signer = await provider.getSigner();
        const connectedMedical = medical.connect(signer);
        const myRecords = await connectedMedical.getMyRecords();
        additionalInfo.totalRecords = myRecords.length;
      } catch (error) {
        additionalInfo.totalRecords = "Access denied";
      }
    }
    
    // Додаткова інформація для лікарів
    if (role === 2) { // DOCTOR
      try {
        const signer = await provider.getSigner();
        const connectedMedical = medical.connect(signer);
        const doctorPendingRecords = await connectedMedical.getDoctorPendingRecords();
        additionalInfo.pendingRecords = doctorPendingRecords.length;
      } catch (error) {
        additionalInfo.pendingRecords = "Access denied";
      }
    }
    
    return {
      address: userAddress,
      role: roleNames[role],
      isRegistered,
      balance: ethers.utils.formatEther(balance),
      ...additionalInfo
    };
    
  } catch (error) {
    console.error(`Error getting user details for ${userAddress}:`, error);
    return null;
  }
};

// Функція для пошуку користувача за адресою
export const searchUser = async (medical, userAddress, provider) => {
  try {
    if (!userAddress || !userAddress.match(/^0x[a-fA-F0-9]{40}$/)) {
      throw new Error("Invalid Ethereum address");
    }
    
    const userDetails = await getUserDetails(medical, userAddress, provider);
    return userDetails;
    
  } catch (error) {
    console.error("Error searching user:", error);
    throw error;
  }
};