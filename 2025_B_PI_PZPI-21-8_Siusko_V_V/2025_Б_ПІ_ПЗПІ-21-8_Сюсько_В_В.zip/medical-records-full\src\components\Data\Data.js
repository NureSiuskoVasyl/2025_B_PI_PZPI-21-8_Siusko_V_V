import React, { useEffect } from "react";
import "./data.css";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { deleteData, loadMyRecords, loadAllRecords } from "../../store/interactions";
import { userRoleSelector, recordsForCurrentUserSelector } from "../../store/selectors";

const Data = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const account = useSelector((state) => state.provider.account);
  const provider = useSelector((state) => state.provider.connection);
  const medical = useSelector((state) => state.medical.contract);
  const userRole = useSelector(userRoleSelector);
  const records = useSelector(recordsForCurrentUserSelector);

  // Завантажуємо записи в залежності від ролі
  useEffect(() => {
    if (medical && account && userRole.isRegistered) {
      if (userRole.isPatient) {
        // Пацієнт - завантажуємо тільки свої записи
        loadMyRecords(medical, dispatch);
      } else if (userRole.isDoctor || userRole.isAdmin) {
        // Лікар/Адмін - завантажуємо всі записи
        loadAllRecords(medical, dispatch);
      }
    }
  }, [medical, account, userRole.role, dispatch]);

  const deleteHandler = (e, record) => {
    // Перевіряємо права на видалення
    if (!userRole.isDoctor && !userRole.isAdmin) {
      alert(t('dataTable.onlyDoctorsDelete'));
      return;
    }

    if (window.confirm(t('dataTable.confirmDelete'))) {
      deleteData(medical, record.recordId, dispatch, provider);
    }
  };

  if (!account) {
    return (
      <div className="data-container">
        <h1>{t('dataTable.connectWallet')}</h1>
        <p>{t('dataTable.connectWalletText')}</p>
      </div>
    );
  }

  if (!userRole.isRegistered) {
    return (
      <div className="data-container">
        <h1>{t('dataTable.registrationRequired')}</h1>
        <p>{t('dataTable.registrationText')}</p>
        <p>{t('form.currentRole')}: {userRole.role}</p>
      </div>
    );
  }

  return (
    <div className="data-container">
      {/* Заголовок в залежності від ролі */}
      <div className="data-header">
        {userRole.isPatient && (
          <div className="patient-header">
            <h1>{t('dataTable.patientTitle')}</h1>
            <p>{t('roles.patient')}: {account.slice(0, 6)}...{account.slice(-4)}</p>
            <p className="privacy-note">{t('dataTable.patientSubtitle')}</p>
          </div>
        )}
        
        {(userRole.isDoctor || userRole.isAdmin) && (
          <div className="doctor-header">
            <h1>{t('dataTable.doctorTitle')}</h1>
            <p>{userRole.isDoctor ? t('roles.doctor') : t('roles.admin')}: {account.slice(0, 6)}...{account.slice(-4)}</p>
            <p className="access-note">{userRole.isDoctor ? t('dataTable.doctorSubtitle') : t('dataTable.adminSubtitle')}</p>
          </div>
        )}
      </div>

      {/* Таблиця записів */}
      {records && records.length > 0 ? (
        <div className="table-container">
          <table className="records-table">
            <thead>
              <tr>
                <th>{t('dataTable.headers.recordId')}</th>
                <th>{t('dataTable.headers.dateTime')}</th>
                {(userRole.isDoctor || userRole.isAdmin) && (
                  <>
                    <th>{t('dataTable.headers.patient')}</th>
                    <th>{t('dataTable.headers.doctor')}</th>
                  </>
                )}
                <th>{t('dataTable.headers.name')}</th>
                <th>{t('dataTable.headers.age')}</th>
                <th>{t('dataTable.headers.gender')}</th>
                <th>{t('dataTable.headers.bloodType')}</th>
                <th>{t('dataTable.headers.allergies')}</th>
                <th>{t('dataTable.headers.diagnosis')}</th>
                <th>{t('dataTable.headers.treatment')}</th>
                {(userRole.isDoctor || userRole.isAdmin) && (
                  <th>{t('dataTable.headers.actions')}</th>
                )}
              </tr>
            </thead>
            <tbody>
              {records.map((record, index) => (
                <tr key={index} className="record-row">
                  <td>{record.recordId}</td>
                  <td>{record.formattedTimestamp}</td>
                  
                  {/* Показуємо адреси тільки лікарям/адмінам */}
                  {(userRole.isDoctor || userRole.isAdmin) && (
                    <>
                      <td className="address-cell">
                        <span className="address-short">{record.shortPatient}</span>
                        <span className="address-full">{record.patient}</span>
                      </td>
                      <td className="address-cell">
                        <span className="address-short">{record.shortDoctor}</span>
                        <span className="address-full">{record.doctor}</span>
                      </td>
                    </>
                  )}
                  
                  <td>{record.name}</td>
                  <td>{record.age}</td>
                  <td>{record.gender}</td>
                  <td>{record.bloodType}</td>
                  <td>{record.allergies}</td>
                  <td>{record.diagnosis}</td>
                  <td>{record.treatment}</td>
                  
                  {/* Кнопка видалення тільки для лікарів/адмінів */}
                  {(userRole.isDoctor || userRole.isAdmin) && (
                    <td>
                      <button
                        className="delete-button"
                        onClick={(e) => deleteHandler(e, record)}
                      >
                        {t('dataTable.deleteButton')}
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="no-records">
          {userRole.isPatient ? (
            <div className="patient-no-records">
              <h2>{t('dataTable.noRecords')}</h2>
              <p>{t('dataTable.patientNoRecords')}</p>
              <p>{t('dataTable.patientNoRecordsHelper')}</p>
            </div>
          ) : (
            <div className="doctor-no-records">
              <h2>{t('dataTable.doctorNoRecords')}</h2>
              <p>{t('dataTable.doctorNoRecordsHelper')}</p>
              <p>{t('dataTable.addRecordsHelper')}</p>
            </div>
          )}
        </div>
      )}

      {/* Статистика для лікарів/адмінів */}
      {(userRole.isDoctor || userRole.isAdmin) && records.length > 0 && (
        <div className="statistics">
          <div className="stat-card">
            <h3>{t('dataTable.statistics')}</h3>
            <p>{t('dataTable.totalRecords')} {records.length}</p>
            <p>{t('dataTable.uniquePatients')} {new Set(records.map(r => r.patient)).size}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Data;