import React from "react";
import "./navbar.css";
import healthReport from "../../assets/health-report.png";
import { loadAccount } from "../../store/interactions";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import Blockies from "react-blockies";
import { userRoleSelector } from "../../store/selectors";
import LanguageSelector from "../LanguageSelector/LanguageSelector";

const Navbar = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const provider = useSelector((state) => state.provider.connection);
  const account = useSelector((state) => state.provider.account);
  const balance = useSelector((state) => state.provider.balance);
  const userRole = useSelector(userRoleSelector);
  
  const connectHandler = async (e) => {
    await loadAccount(provider, dispatch);
  };

  const getRoleDisplay = () => {
    if (!userRole.isRegistered) {
      return <span className="nav__role nav__role--none">{t('roles.notRegistered')}</span>;
    }
    
    switch (userRole.role) {
      case "ADMIN":
        return <span className="nav__role nav__role--admin">{t('roles.admin')}</span>;
      case "DOCTOR":
        return <span className="nav__role nav__role--doctor">{t('roles.doctor')}</span>;
      case "PATIENT":
        return <span className="nav__role nav__role--patient">{t('roles.patient')}</span>;
      default:
        return <span className="nav__role nav__role--none">{t('roles.noRole')}</span>;
    }
  };
  
  return (
    <div className="Navbar">
      <div className="nav__name">
        <img src={healthReport} alt="" width="40" height="40" />
        <h2>{t('navbar.title')}</h2>
      </div>

      {/* Показуємо роль користувача */}
      {account && (
        <div className="nav__userInfo">
          {getRoleDisplay()}
        </div>
      )}
      
      <div className="nav__balance">
        {balance ? (
          <p className="nav__myBalance">
            <small>{t('navbar.balance')}: </small>
            {Number(balance).toFixed(4)} ETH
          </p>
        ) : (
          <p className="nav__myBalance">
            <small>{t('navbar.balance')}: </small>
            0 ETH
          </p>
        )}
        {account ? (
          <a className="nav__myAccount" href="#">
            {account.slice(0, 5) + "...." + account.slice(38, 42)}
            <Blockies
              seed={account}
              size={10}
              scale={3}
              color="#2187D0"
              bgColor="#F1F2F9"
              spotColor="#767F92"
              className="identicon"
            />
          </a>
        ) : (
          <button className="nav__balance-box" onClick={connectHandler}>
            {t('navbar.connect')}
          </button>
        )}
        
        {/* Додаємо LanguageSelector */}
        <LanguageSelector />
      </div>
    </div>
  );
};

export default Navbar;