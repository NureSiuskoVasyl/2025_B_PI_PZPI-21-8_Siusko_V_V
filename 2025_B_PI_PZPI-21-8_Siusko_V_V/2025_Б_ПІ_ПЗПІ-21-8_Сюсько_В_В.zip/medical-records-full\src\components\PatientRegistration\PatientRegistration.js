import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { registerAsPatient } from "../../store/interactions";
import { userRoleSelector } from "../../store/selectors";
import "./patientRegistration.css";

const PatientRegistration = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const provider = useSelector((state) => state.provider.connection);
  const medical = useSelector((state) => state.medical.contract);
  const account = useSelector((state) => state.provider.account);
  const userRole = useSelector(userRoleSelector);
  const [isLoading, setIsLoading] = useState(false);

  const registerHandler = async (e) => {
    e.preventDefault();
    
    if (!account) {
      alert(t('registration.connectWalletText'));
      return;
    }

    if (userRole.isRegistered) {
      alert("You are already registered in the system");
      return;
    }

    setIsLoading(true);
    try {
      await registerAsPatient(medical, provider, dispatch);
      alert("Successfully registered as patient!");
    } catch (error) {
      console.error("Registration failed:", error);
      alert("Registration failed. Check console for details.");
    }
    setIsLoading(false);
  };

  if (!account) {
    return (
      <div className="registration-container">
        <h1>{t('registration.connectWallet')}</h1>
        <p>{t('registration.connectWalletText')}</p>
      </div>
    );
  }

  if (userRole.isRegistered) {
    return (
      <div className="registration-container">
        <div className="already-registered">
          <h1>{t('registration.alreadyRegistered')}</h1>
          <p>{t('registration.currentRole')} <strong>{userRole.role}</strong></p>
          <p>{t('registration.account')} {account.slice(0, 6)}...{account.slice(-4)}</p>
          
          {userRole.isPatient && (
            <div className="patient-info">
              <h2>{t('registration.patientDashboard')}</h2>
              <p>{t('registration.patientDashboardText')}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="registration-container">
      <div className="registration-card">
        <h1>{t('registration.title')}</h1>
        <div className="account-info">
          <p><strong>{t('registration.account')}</strong> {account.slice(0, 6)}...{account.slice(-4)}</p>
          <p><strong>{t('registration.fullAddress')}</strong> <code>{account}</code></p>
        </div>

        <div className="registration-info">
          <h2>{t('registration.whatHappens')}</h2>
          <ul>
            <li>{t('registration.benefits.0')}</li>
            <li>{t('registration.benefits.1')}</li>
            <li>{t('registration.benefits.2')}</li>
            <li>{t('registration.benefits.3')}</li>
          </ul>
        </div>

        <form onSubmit={registerHandler}>
          <div className="terms">
            <p>
              <strong>{t('registration.privacyNotice')}</strong> {t('registration.privacyText')}
            </p>
          </div>
          
          <button 
            type="submit" 
            disabled={isLoading}
            className="register-btn"
          >
            {isLoading ? t('registration.registering') : t('registration.registerBtn')}
          </button>
        </form>

        <div className="help-section">
          <h3>{t('registration.needHelp')}</h3>
          <p>{t('registration.doctorHelp')}</p>
          <p>{t('registration.technicalHelp')}</p>
        </div>
      </div>
    </div>
  );
};

export default PatientRegistration;